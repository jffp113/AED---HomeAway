package homeAway;


public class PropertyAlreadyVisitedException extends Exception {

	private static final long serialVersionUID = 0L;

}
