package homeAway;

public class NoSearchResultsException extends Exception {

	private static final long serialVersionUID = 0L;

}
