package homeAway;


public class TravellerIsOwnerException extends Exception{

	private static final long serialVersionUID = 0L;

}
