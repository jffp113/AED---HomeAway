package homeAway;

public class PropertyDoesNotExistException extends Exception {

	private static final long serialVersionUID = 0L;

}
