package homeAway;

public class TravellerIsNotOwnerException extends Exception{

	private static final long serialVersionUID = 0L;

}
