package homeAway;


public class UserIsNotTravellerException extends Exception {

	private static final long serialVersionUID = 0L;

}
