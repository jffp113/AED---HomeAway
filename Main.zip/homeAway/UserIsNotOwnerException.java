package homeAway;


public class UserIsNotOwnerException extends Exception {

	private static final long serialVersionUID = 0L;

}
